nama = input("masukkan nama kamu ")

print ("Halo, perkenalkan nama saya",nama)