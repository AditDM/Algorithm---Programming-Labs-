sisi = int(input("masukkan Sisi Yang Anda Inginkan "))
d1 = 4
d2 = (((sisi**2) - (d1**2))**(0.5))

l = ((d1*d2)/2)
Luas = (l*4)


print ("Luas Bela Ketupat Ialah",Luas)