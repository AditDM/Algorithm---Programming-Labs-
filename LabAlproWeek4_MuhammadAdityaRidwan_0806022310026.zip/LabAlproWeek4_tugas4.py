HargaAwal = int(input("Masukkan Harga Awal "))
Diskon = 10

PotonganDiskon = HargaAwal / Diskon
HasilDiskon = HargaAwal - PotonganDiskon

print ("Harga Setelah Diskon 10 persen anda ialah", HasilDiskon) 