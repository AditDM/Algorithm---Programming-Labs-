a = int(input("masukkan alas "))
t = int(input("masukkan tinggi "))

luas = (1/2 * a * t)

print ("luas bangun datar segitiga adalah ", luas)