a = int(input("masukkan a "))
b = int(input("masukkan b "))
c = int(input("masukkan c "))

D = b**2 - 2 * a * c 

print ("nilai hasil Determinan ini ialah", D)